package Servlet;

import java.io.IOException;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import Utils.SQLUtils;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		SQLUtils sqlUtils = SQLUtils.getInstance();
		String username = (String) request.getParameter("username");
		String password = (String) request.getParameter("password");
		//status login登录  sign注册
		String status = request.getParameter("type");
		if (status.equals("login")) {
			if(sqlUtils.hasSigned(username, password)){
				request.getSession().setAttribute("username", username);
				request.getSession().setMaxInactiveInterval(Integer.MAX_VALUE);
				response.getWriter().print("1");  		//登录成功
			}else {
				if (sqlUtils.nameExist(username)) {
					response.getWriter().print("-1");    //密码错误
				}
			}			
		}else if(status.equals("sign")) {
			if (sqlUtils.nameExist(username)) {
				response.getWriter().print("-1");    	//用户名已存在
			}else {
				request.getSession().setAttribute("username", username);
				request.getSession().setMaxInactiveInterval(Integer.MAX_VALUE);
				request.getSession().setAttribute("username", username);
				response.getWriter().print(sqlUtils.insertUser(username, password));
			}
		}
	}

}
