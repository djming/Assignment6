package Servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Utils.CartUtils;
import Utils.SQLUtils;
import mainobj.Pet;

/**
 * Servlet implementation class Cart
 */
@WebServlet("/Cart")
public class Cart extends HttpServlet {
	private static final long serialVersionUID = 1L;
	List<Pet> pets;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Cart() {
		super();
		pets = SQLUtils.getInstance().getAllPets();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println(request.getParameterMap().toString());
		response.getWriter().print("successed!You have bought"
				+ CartUtils.getInstance().getCartInfo((String) request.getSession().getAttribute("username")));
		
		CartUtils.getInstance().clearCart((String) request.getSession().getAttribute("username"));
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String username = (String) request.getSession().getAttribute("username");
		int id = Integer.valueOf(request.getParameter("id"));
		CartUtils.getInstance().addAni(username, pets.get(id).getName());
		response.getWriter().print(CartUtils.getInstance().getPage(username));
	}

}
