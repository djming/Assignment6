package Utils;

import java.util.ArrayList;
import java.util.List;

import com.sun.javafx.geom.PickRay;

import mainobj.UserCart;
import mainobj.petInCart;

public class CartUtils {
	List<UserCart> ucs;
	public static CartUtils cu;
	public CartUtils(){
		ucs = new ArrayList<>();
	}
	public static CartUtils getInstance(){
		if (cu==null) {
			cu = new CartUtils();
		}
		return cu;
	}
	public void addAni(String username,String aniName){
		boolean add = false;
		for(UserCart uc:ucs){
			if (username.equals(uc.getUsername())) {
				uc.addAni(aniName);
				add=true;
			}
		}
		if (!add) {
			UserCart uc = new UserCart(username);
			uc.addAni(aniName);
			ucs.add(uc);
		}
	}
	public String getPage(String username){
		for(UserCart uc:ucs){
			if (uc.getUsername().equals(username)) {
				return uc.getPage();
			}
		}
		return "";
	}
	public void clearCart(String username){
		for(UserCart uc:ucs){
			if (uc.getUsername().equals(username)) {
				uc.clear();
			}
		}
	}
	public String getCartInfo(String username){
		for(UserCart uc:ucs){
			if (uc.getUsername().equals(username)) {
				return uc.getCartInfo();
			}
		}
		return "";
	}
}
