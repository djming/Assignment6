package Utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sun.org.apache.regexp.internal.recompile;

import mainobj.Pet;



public class SQLUtils {
	private static SQLUtils sqlUtils;
	private Connection conn;
	private PreparedStatement pstmt;
	public SQLUtils(){
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://127.0.0.1:3306/my_schema?useUnicode=true&characterEncoding=UTF-8";
			conn = DriverManager.getConnection(url,"root","123456");
		} catch (SQLException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	public static SQLUtils getInstance(){
		if (sqlUtils == null) {
			sqlUtils = new SQLUtils();
		}
		return sqlUtils;
	}
	
	//判断账户是否存在
	public boolean hasSigned(String username,String password){
		ResultSet rs;
		boolean b = false;
		try {
			pstmt = conn.prepareStatement("select * from 2014302580313_user where username=? and password=?");
			pstmt.setString(1, username);
			pstmt.setString(2, password);
			rs = pstmt.executeQuery();
			b= rs.next();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return b;
	}
	//判断用户名是否存在
	public boolean nameExist(String username) {
		boolean existed = false;
		ResultSet rs;
		try {
			pstmt = conn.prepareStatement("select * from 2014302580313_user where username=?");
			pstmt.setString(1, username);
			rs = pstmt.executeQuery();
			existed= rs.next();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return existed;
	}
	
	//新增用户
	public int insertUser(String username,String password){
		try {
			pstmt = conn.prepareStatement("INSERT INTO 2014302580313_user(username,password) values(?,?)");
			pstmt.setString(1, username);
			pstmt.setString(2, password);
			pstmt.executeUpdate();
			return 1; 		//增加成功
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return -1;		//增加失败
		}
	}
	public List<Pet> getAllPets(){
		Pet pet = new Pet();
		List<Pet> pets = new ArrayList<>();
		try {
			ResultSet rs = conn.prepareStatement("SELECT * FROM pet").executeQuery();
			while (rs.next()) {
				pet = new Pet(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6));
				pets.add(pet);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pets;
	}
}
