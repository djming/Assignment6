package mainobj;

public class petInCart {
	private int id;
	private String name;
	private int num;
	public petInCart(){
		
	}
	public petInCart(String name,int num){
		this.name = name;
		this.num = num;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	
	public void addNum(){
		this.num++;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
}
