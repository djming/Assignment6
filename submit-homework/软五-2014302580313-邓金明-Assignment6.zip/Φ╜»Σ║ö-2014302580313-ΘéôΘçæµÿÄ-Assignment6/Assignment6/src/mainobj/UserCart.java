package mainobj;

import java.util.ArrayList;
import java.util.List;

public class UserCart {
	String username;
	String pageBody;
	petInCart pic;
	List<petInCart> pics=new ArrayList<>();
	public UserCart(String username){
		this.username = username;
		pageBody = "";
	}
	
	public void addAni(String name){
		boolean exist = false;
		for(int i=0;i<pics.size();i++){
			if (name.equals(pics.get(i).getName())) {
				pics.get(i).addNum();
				exist = true;
				break;
			}
		}
		if (!exist) {
			pic = new petInCart(name, 1);
			pics.add(pic);
		}
	}
	public String getPage(){
		String page = "";
		for(petInCart pic: this.pics){
			page += "<tr><td>"+pic.getName()+"</td><td>"+pic.getNum()+"</td><td>"+400+"</td></tr>";
		}
		return page;
	}
	public String getUsername(){
		return this.username;
	}
	public String getCartInfo(){
		String info = "";
		for(int i=0;i<pics.size();i++){
			info+=" "+pics.get(i).getName()+"*"+pics.get(i).getNum()+" ";
		}
		return info;
	}
	public void clear(){
		this.pics = new ArrayList<>();
	}
}
